﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace REGISTER
{
    public partial class mem_edit : Form
    {
        DBClass dbc = new DBClass();
        public mem_edit()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void mem_edit_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int status = 0;

            DataTable memberTable = dbc.ExecuteQuery("select * from member");

            string updateid = textBox1.Text;
            string udtpw = textBox2.Text;
            string udtname = textBox3.Text;
            string udtphone = textBox4.Text + "-" + textBox5.Text + "-" + textBox6.Text;

            // 중복 ID 확인
            bool isDuplicateID = memberTable.AsEnumerable().Any(row => row.Field<string>("MID") == updateid);

            if (isDuplicateID)
            {
                MessageBox.Show("중복된 아이디 입니다.");
            }
            else
            {
                int rowsAffected = dbc.ExecuteNonQuery($"UPDATE MEMBER SET MID= '{updateid}', PASSWORD = '{udtpw}', NAME = '{udtname}', PNUMBER = '{udtphone}'  WHERE NAME = '{udtname}'");

                if (rowsAffected > 0)
                {
                    MessageBox.Show("회원정보 수정 완료");
                    this.Visible = false;             // 추가
                    mypage MyPage = new mypage();
                    MyPage.ShowDialog();
                    this.Close();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DataTable memberTable = dbc.ExecuteQuery("select * from member");

            string id = textBox1.Text;
            string pw = textBox2.Text;

            bool isDuplicateID2 = memberTable.AsEnumerable().Any(row => row.Field<string>("MID") == id);
            bool isDuplicatePW2 = memberTable.AsEnumerable().Any(row => row.Field<string>("PASSWORD") == pw);

            if (isDuplicateID2)
            {
                if (isDuplicatePW2)
                {
                    int rowsAffected = dbc.ExecuteNonQuery($"DELETE FROM MEMBER WHERE MID= '{id}'");

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("회원 탈퇴 되었습니다.");
                        this.Visible = false;             // 추가
                        Lecture lecture = new Lecture();
                        lecture.ShowDialog();
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("비밀번호가 일치하지 않습니다.");
                }
            } else
            {
                MessageBox.Show("아이디를 확인해주세요.");
            }
        }
    }
}
