﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace REGISTER
{
    public partial class Form1 : Form
    {
        DBClass dbc = new DBClass();
        public Form1()
        {
            InitializeComponent();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // int login_status = 0; 
            string loginid = textBox1.Text;
            string loginpw = textBox2.Text;
            string username = textBox3.Text;
            string userage = textBox4.Text;
            string userphone = textBox5.Text + textBox6.Text + textBox7.Text;
            int rowsAffected = dbc.ExecuteNonQuery($"INSERT INTO MEMBER(ID, PASSWORD, NAME, AGE, PNUMBER) VALUES ('{loginid}', '{loginpw}', '{username}', '{userage}', '{userphone}')");

            if (rowsAffected > 0)
            {
                MessageBox.Show("회원 가입 성공!");
            }
            else
            {
                MessageBox.Show("회원 가입 실패.");
            }
        }
    }
}
