﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace REGISTER
{
    public partial class Login : Form
    {
        DBClass dbc = new DBClass();
        public Login()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string enteredID = textBox1.Text;
            string enteredPassword = textBox2.Text;

            // 데이터베이스에서 사용자 정보 가져오기
            DataTable memberTable = dbc.ExecuteQuery($"SELECT NAME FROM MEMBER WHERE MID = '{enteredID}' AND PASSWORD = '{enteredPassword}'");

            if (memberTable.Rows.Count > 0)
            {
                string loggedInUserName = memberTable.Rows[0]["NAME"].ToString();

                // 로그인 성공 메시지 표시
                MessageBox.Show($"로그인 성공! 환영합니다, {loggedInUserName}님!");

                this.Visible = false;             // 추가
                mypage MyPage = new mypage(loggedInUserName);
                MyPage.ShowDialog();
                this.Close();
            }
            else
            {
                // 로그인 실패 메시지 표시
                MessageBox.Show("로그인 실패. 아이디 또는 비밀번호를 확인해주세요.");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Visible = false;             // 추가
            Form1 register = new Form1();
            register.ShowDialog();
            this.Close();
        }
    }
}
